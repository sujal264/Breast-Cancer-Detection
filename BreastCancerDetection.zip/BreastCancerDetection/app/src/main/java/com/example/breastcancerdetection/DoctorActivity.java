package com.example.breastcancerdetection;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URL;

public class DoctorActivity extends AppCompatActivity {
TextView fmobile,smobile,third,four,fivemobile;
Button fb,fcall,swat,sbcall,tcall,forcall,fivecall;
Button twhatapp,fwhatapp,fivewhatapp;
    String phoneno,sphone,tphone,fphone,five;
    static int PERMISSION_CODE= 100;
    Context context=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor);

        fmobile=(TextView) findViewById(R.id.txtfirstcall);
        smobile=(TextView)findViewById(R.id.txt_secondmobile);
        fb=(Button) findViewById(R.id.btn_fdr);
        swat=(Button)findViewById(R.id.btn_secondwhatapp);
        fcall=(Button) findViewById(R.id.btn_fcall);
        sbcall=(Button) findViewById(R.id.btn_secondfcall);
        third=(TextView) findViewById(R.id.txxt_thirdcall);
        twhatapp=(Button) findViewById(R.id.btn_thirtwatapp);
        tcall=(Button) findViewById(R.id.btn_thirdfcall);
        four=(TextView) findViewById(R.id.txtsfourtcall);
        fwhatapp=(Button) findViewById(R.id.btn_fourfdr);
        forcall=(Button) findViewById(R.id.btn_fourcall);
        fivemobile=(TextView) findViewById(R.id.txtfivecall);
        fivewhatapp=(Button) findViewById(R.id.btn_fivefdr);
        fivecall=(Button) findViewById(R.id.btn_fivefcall);


        if (ContextCompat.checkSelfPermission(DoctorActivity.this, android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){

            ActivityCompat.requestPermissions(DoctorActivity.this,new String[]{Manifest.permission.CALL_PHONE},PERMISSION_CODE);

        }


        fivecall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                five = fivemobile.getText().toString();
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:"+five));
                startActivity(i);
            }
        });

        fivewhatapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                five = fivemobile.getText().toString();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,  five+"Hello Doctor.");
                //  sendIntent.putExtra("Doctor", phoneno + "@s.whatsapp.net");
                sendIntent.setType("text/plain");
                sendIntent.setPackage("com.whatsapp");
                startActivity(Intent.createChooser(sendIntent, ""));
                startActivity(sendIntent);
            }
        });

        forcall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fphone = four.getText().toString();
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:"+fphone));
                startActivity(i);
            }
        });

        fwhatapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fphone = four.getText().toString();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,  fphone+"Hello Doctor.");
                //  sendIntent.putExtra("Doctor", phoneno + "@s.whatsapp.net");
                sendIntent.setType("text/plain");
                sendIntent.setPackage("com.whatsapp");
                startActivity(Intent.createChooser(sendIntent, ""));
                startActivity(sendIntent);
            }
        });


        tcall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tphone = third.getText().toString();
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:"+tphone));
                startActivity(i);
            }
        });

        twhatapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tphone = third.getText().toString();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,  tphone+"Hello Doctor.");
                //  sendIntent.putExtra("Doctor", phoneno + "@s.whatsapp.net");
                sendIntent.setType("text/plain");
                sendIntent.setPackage("com.whatsapp");
                startActivity(Intent.createChooser(sendIntent, ""));
                startActivity(sendIntent);
            }
        });

        sbcall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sphone = smobile.getText().toString();
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:"+sphone));
                startActivity(i);
            }
        });

        swat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sphone = smobile.getText().toString();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,  sphone+"Hello Doctor.");
                //  sendIntent.putExtra("Doctor", phoneno + "@s.whatsapp.net");
                sendIntent.setType("text/plain");
                sendIntent.setPackage("com.whatsapp");
                startActivity(Intent.createChooser(sendIntent, ""));
                startActivity(sendIntent);
                //opens the portfolio details class
            }
        });

        fcall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              phoneno = fmobile.getText().toString();
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:"+phoneno));
                startActivity(i);
            }
        });
        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                phoneno = fmobile.getText().toString();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,  phoneno+"Hello Doctor.");
              //  sendIntent.putExtra("Doctor", phoneno + "@s.whatsapp.net");
                sendIntent.setType("text/plain");
                sendIntent.setPackage("com.whatsapp");
                startActivity(Intent.createChooser(sendIntent, ""));
                startActivity(sendIntent);
                //opens the portfolio details class

            }

        });



    }


}