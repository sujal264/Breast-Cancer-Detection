package com.example.breastcancerdetection;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ViewProfile extends AppCompatActivity {
    TextView tv1;
    EditText mid, name, address, phone, password;
    Button register;
    TestAdapter adapter;
    String id, semial, saddress, sphone, spassword;
    String   mobilenum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        mid = (EditText) findViewById(R.id.txt_medicalids);
        name = (EditText) findViewById(R.id.txt_emails);
        address = (EditText) findViewById(R.id.txt_addresss);
        phone = (EditText) findViewById(R.id.txt_phones);
        password = (EditText) findViewById(R.id.txt_passwords);
        register = (Button) findViewById(R.id.btn_pregisters);


        try {

            adapter = new TestAdapter(this);
            adapter.createDatabase();
            adapter.open();
            Bundle bundle = getIntent().getExtras();
            mobilenum = bundle.getString("Key");
            //   smobile.setText(mobile);


            Cursor c=adapter.getMedicalid(mobilenum);
            while (c.moveToNext()) {
                mid.setText(c.getString(0));
                name.setText(c.getString(1));
                address.setText(c.getString(2));
                phone.setText(c.getString(3));
                password.setText(c.getString(4));
            }

        }catch (Exception e){}

            register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ViewProfile.this,HomeActivity.class);
                i.putExtra("Key",mobilenum);
                startActivity(i);
            }
        });
    }
}