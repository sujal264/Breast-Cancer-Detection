package com.example.breastcancerdetection;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ExpandableListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CancerType extends AppCompatActivity {
    android.widget.ExpandableListAdapter listAdapter;
    ExpandableListView expListView;
    List<String> listDataHeader;
    HashMap<String, List<String>> listDataChild;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancer_type);

        expListView = (ExpandableListView) findViewById(R.id.lvExp);

        // preparing list data
        prepareListData();

        listAdapter = new ExpandableListAdapter(this, listDataHeader, listDataChild);

        // setting list adapter
        expListView.setAdapter(listAdapter);
    }

    /*
     * Preparing the list data
     */
    private void prepareListData() {
        listDataHeader = new ArrayList<String>();
        listDataChild = new HashMap<String, List<String>>();

        // Adding child data
      /*  Cancer Detect DCIS Pro
        1 Cancer Detect IDC Stage 3
        2 Cancer Detect LCIS Stage 1 Early
        3 Negative
        4 Invalid Image**/
        listDataHeader.add("Ductal carcinoma in situ (DCIS) ");
        listDataHeader.add("Invasive breast cancer (ILC or IDC) . ");
        listDataHeader.add("Triple-negative breast cancer.  ");
        listDataHeader.add("Inflammatory breast cancer.");
        listDataHeader.add("Paget disease of the breast. ");


       // Adding child data
        List<String> top250 = new ArrayList<String>();
        top250.add("DCIS is considered the earliest form of breast cancer. has a low risk of becoming invasive");
        top250.add("DCIS is noninvasive meaning it hasn't spread out of the milk duct");
        top250.add("DCIS doesn't typically have any signs or symptoms. However, DCIS can sometimes cause signs such as:");
        top250.add("A breast lump,Bloody nipple discharge");


        List<String> nowShowing = new ArrayList<String>();
        nowShowing.add("Breast cancers that have spread into surrounding breast tissue are known as invasive breast cancers");
        nowShowing.add("This is the most common type of breast cancer. .");
        nowShowing.add("About 8 in 10 invasive breast cancers are invasive (or infiltrating) ductal carcinomas (IDC)");
        nowShowing.add("IDC starts in the cells that line a milk duct in the breast. From there, the cancer breaks through the wall of the duct, and grows into the nearby breast tissues");
        nowShowing.add(" Invasive lobular carcinoma may be harder to detect on physical exam and imaging, like mammograms, than invasive ductal carcinoma");

        List<String> comingSoon = new ArrayList<String>();
        comingSoon.add("Triple-negative breast cancer (TNBC) accounts for about 10-15% of all breast cancers.");
        comingSoon.add("term triple-negative breast cancer refers to the fact that the cancer cells don’t have estrogen or progesterone receptors");
        comingSoon.add("TNBC tends to grow quickly, is more likely to have spread at the time it’s found, and is more likely to come back after treatment than other types of breast cancer");
        comingSoon.add("A relative survival rate compares women with the same type and stage of breast cancer to women in the overall population");


        List<String> cancer = new ArrayList<String>();
        cancer.add("Inflammatory breast cancer is a rare and very aggressive disease in which cancer cells block lymph vessels in the skin of the breast.");
        cancer.add("This type of breast cancer is called “inflammatory” because the breast often looks swollen and red, or inflamed.");
        cancer.add("Compared with other types of breast cancer, inflammatory breast cancer tends to be diagnosed at younger ages.");
        cancer.add("nflammatory breast cancer is more common and diagnosed at younger ages in African American women than in white women.");
        cancer.add("Inflammatory breast cancer is more common in obese women than in women of normal weight. ");


        listDataChild.put(listDataHeader.get(0), top250); // Header, Child data
        listDataChild.put(listDataHeader.get(1), nowShowing);
        listDataChild.put(listDataHeader.get(2), comingSoon);
        listDataChild.put(listDataHeader.get(3), cancer);


    }
}